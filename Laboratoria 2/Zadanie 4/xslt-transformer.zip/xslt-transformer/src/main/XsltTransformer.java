package main;

import java.io.UnsupportedEncodingException;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import net.sf.saxon.TransformerFactoryImpl;

public class XsltTransformer {
	public static void main(String[] args) {
		if (args.length < 3) {
			System.out.println("Nie podano wystarczaj�cej liczby parametr�w wyj�ciowych.\n" + 
					"Poprawny format: xml xslt output.");
			return;
		}
		
		try {
			transform(args[0], args[1], args[2]);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void transform(String xmlPath, String xsltPath, String outputPath) 
			throws TransformerException, UnsupportedEncodingException {
        
		Source xml = new StreamSource(xmlPath);
        Source xslt = new StreamSource(xsltPath);

        TransformerFactory transFact = TransformerFactoryImpl.newInstance();
        Transformer trans = transFact.newTransformer(xslt);

        Result result = new StreamResult(outputPath);        
        trans.transform(xml, result);
	}
}
